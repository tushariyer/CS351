
CS 351 - Intro. to Artificial Intelligence
Tushar Iyer & Aaron Shea

This is the directory for the Semester Project. This file is also used as a Git log to monitor changes and to learn Git commands through the command line.

 - Used nano not vim.
